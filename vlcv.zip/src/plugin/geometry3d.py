
from typing import Iterable, List, Tuple
import numpy as np
import open3d as o3d
import pytorch3d.structures
import torch



def cvt_meshes_torch3d_to_o3d(meshes: pytorch3d.structures.Meshes) -> Iterable[o3d.geometry.TriangleMesh]:
    meshes_o3d = []
    for i_mesh in range(len(meshes)):
        [verts, faces] = meshes.get_mesh_verts_faces(i_mesh)
        mesh_o3d = o3d.geometry.TriangleMesh(
            o3d.utility.Vector3dVector(verts.cpu().numpy()),
            o3d.utility.Vector3iVector(faces.cpu().numpy()),
        )
        meshes_o3d.append(mesh_o3d)
    return meshes_o3d


def cvt_meshes_o3d_to_torch3d(meshes: Iterable[o3d.geometry.TriangleMesh], device="cuda:0") -> pytorch3d.structures.Meshes:
    verts_list = []
    faces_list = []
    for mesh in meshes:
        v = np.asarray(mesh.vertices).astype(np.float32)
        f = np.asarray(mesh.triangles).astype(int)
        verts_list.append(torch.from_numpy(v))
        faces_list.append(torch.from_numpy(f))
    meshes_torch3d = pytorch3d.structures.Meshes(verts=verts_list, faces=faces_list)
    meshes_torch3d = meshes_torch3d.to(device)
    return meshes_torch3d